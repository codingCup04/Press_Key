
from pynput.keyboard import Key, Controller
import time
keyb = Controller()
keyb.press(Key.cmd)
keyb.press('x')
#keyb.press(Key.esc)
keyb.release(Key.cmd)
keyb.release('x')
#keyb.release(Key.esc)

time.sleep(0.1)

a = 0
while a < 17:
    keyb.press(Key.down)
    keyb.release(Key.down)
    a += 1
keyb.press(Key.right)
keyb.release(Key.right)
keyb.press(Key.down)
keyb.release(Key.down)
#keyb.press(Key.down)
#keyb.release(Key.down) Enter this code to shut down
keyb.press(Key.enter)
keyb.release(Key.enter)