import pynput, time

kpress = pynput.keyboard.Controller()
stk = pynput.keyboard.Key

def pressKey():
    print("Ready...")
    time.sleep(2)
    print("Copying...")
    kpress.press(stk.ctrl)
    kpress.press("a")
    kpress.press("c")
    kpress.release(stk.ctrl)
    kpress.release("a")
    kpress.release("c")
    print("Done!")
time.sleep(1)
pressKey()
