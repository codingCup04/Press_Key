
from pynput.keyboard import Key, Controller
import time
keyb = Controller()
a = 0
while a < 100:
    keyb.press(Key.media_volume_up)
    keyb.release(Key.media_volume_up)
    a += 1
