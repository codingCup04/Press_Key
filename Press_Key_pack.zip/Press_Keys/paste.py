import pynput, time

kpress = pynput.keyboard.Controller()
stk = pynput.keyboard.Key

def pressKey():
    print("Wait...")
    time.sleep(0.5)
    kpress.press("\x16")
    kpress.release("\x16")
    print("Done!")
time.sleep(1)
pressKey()

