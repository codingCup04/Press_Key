from pynput.keyboard import Key, Controller
import time
keyb = Controller()
a = 0
while a < 100:
    keyb.press(Key.media_volume_down)
    keyb.release(Key.media_volume_down)
    a += 1